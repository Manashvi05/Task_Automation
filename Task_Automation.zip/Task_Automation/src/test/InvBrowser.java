package test;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.Assert;

//import dev.failsafe.internal.util.Assert;
import io.github.bonigarcia.wdm.WebDriverManager;

public class InvBrowser{
	private WebDriver driver;

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless");
        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://www.tendable.com");
    }

    @Test
    public void testTopLevelMenus() {
        // Verify top-level menus
        String[] menus = {"Home", "Our Story", "Our Solution", "Why Tendable"};
        for (String menu : menus) {
            WebElement menuElement = driver.findElement(By.linkText(menu));
            Assert.assertNotNull(menuElement, menu + " menu should be present");
        }
    }

    @Test(dependsOnMethods = "testTopLevelMenus")
    public void testRequestDemoButton() {
        // Verify "Request a Demo" button on each top-level menu page
        String[] menus = {"Home", "Our Story", "Our Solution", "Why Tendable"};
        for (String menu : menus) {
            driver.findElement(By.linkText(menu)).click();
            WebElement demoButton = driver.findElement(By.linkText("Request a Demo"));
            Assert.assertTrue(demoButton.isDisplayed() && demoButton.isEnabled(),
                    "Request a Demo button should be present and active on " + menu + " page");
        }
    }

    @Test
    public void testContactUsForm() {
        // Navigate to Contact Us section and choose Marketing
        driver.get("https://www.tendable.com/contact");
        WebElement marketingOption = driver.findElement(By.id("marketing"));
        marketingOption.click();

        // Fill out the form excluding the "Message" field
        driver.findElement(By.name("name")).sendKeys("Test User");
        driver.findElement(By.name("email")).sendKeys("testuser@example.com");
        driver.findElement(By.name("phone")).sendKeys("1234567890");

        // Submit the form
        driver.findElement(By.id("submit")).click();

        // Check for error message
        WebElement errorMessage = driver.findElement(By.id("message-error"));
        Assert.assertTrue(errorMessage.isDisplayed(), "Error message should appear when Message field is empty");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
	 
    
	public static void main(String[] args) {
		InvBrowser test = new InvBrowser();
        test.setUp();
        test.testTopLevelMenus();
        test.testRequestDemoButton();
        test.testContactUsForm();
        test.tearDown();
    }
			
		
	

   }

